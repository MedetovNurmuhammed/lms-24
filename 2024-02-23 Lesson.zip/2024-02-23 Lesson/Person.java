class Person{
	String name;
}