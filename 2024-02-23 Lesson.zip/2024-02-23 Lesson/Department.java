class Department{
	String name;
	int yearLevel;
	String []courses = {"UME-310","UME-308","UME-302"};
	int studentsNumber;
	String faculty;
	String university;
	
	void printCoursesList(){
		for(String course: courses){
			System.out.println("  --  " + course);
		}
	}
	
	void printInfo(){
			System.out.println("Name: " + this.name);
			System.out.println("Year level: " + this.yearLevel);
			System.out.println("Students number: " + this.studentsNumber);
			System.out.println("Faculty: " + this.faculty);
			System.out.println("University: " + this.university);
			System.out.println("Courses: ");
			this.printCoursesList();
	}
}