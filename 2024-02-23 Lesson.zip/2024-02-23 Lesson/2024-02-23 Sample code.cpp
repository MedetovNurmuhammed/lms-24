#include <iostream>
using namespace std;

struct listElement{
	int data;
	listElement *next;
};

void addItem(int itemIndex){
	itemIndex = 5;
	cout<<"addItem function. itemIndex = "<<itemIndex<<endl;
}

void deleteItem(int itemIndex){
}

void printList(listElement *temp){
    int data;
  while(temp != NULL){
      data = temp->data;
	  cout<<data<<" - ";
	  temp = temp->next;
  }
}

int main() {
   
  listElement *top;
  top = new listElement;
  
  top->data = 1913;
  
  listElement *temp = new listElement;
  top->next = temp;
  
  temp->data = 2550;
  
  temp->next = new listElement;
  temp = temp->next;
  temp->data = 2555;
  
  printList(top);
  
  int index = 3;
  addItem(index);
  
  cout<<"main function. index = "<<index<<endl;
  return 0; // Garbage collector
}
