class Exercise03{
	public static void main(String [] args){
		Department ume3 = new Department();
		ume3.name = "UME-3";
		ume3.yearLevel = 3;
		ume3.studentsNumber = 13;
		ume3.faculty = "Natural Sciences Faculty";
		ume3.university = "KTU 'Manas'";
		
		System.out.println("--------------- Department data: ");
		ume3.printInfo();
		
		Student islam = new Student();
		islam.name = "Islambek";
		islam.stNo = "2012.01018";
		
		islam.assignDepartment(ume3);
		
		System.out.println("--------------- Islam student data: ");
		
		islam.changeDepartmentName("UME_3");
		
		islam.department.printInfo();
		
		System.out.println("--------------- Department data: ");
		ume3.printInfo();
	}
}