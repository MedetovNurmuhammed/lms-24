class Student extends Person{
	String stNo;
	Department department;
	
	void assignDepartment(Department newDepartment){
		this.department = newDepartment;
	}
	
	void changeDepartmentName(String newDepName){
		this.department.name = newDepName;
	}
}